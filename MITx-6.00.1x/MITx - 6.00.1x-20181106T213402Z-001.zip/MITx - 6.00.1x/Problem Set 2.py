##------------Problem 1-----------
balance = 42
annualInterestRate = 0.2
monthlyPaymentRate = 0.04
# the able 3 fields are not for edx

monthlyInterestRate = annualInterestRate / 12
x = 1

while x <= 12:
    minMonthlyPayment = monthlyPaymentRate * balance
    monthlyUnpaidBalance = balance - minMonthlyPayment
    balance = monthlyUnpaidBalance + (monthlyInterestRate * monthlyUnpaidBalance)
    x += 1
print(round(balance,2))

##-----------Problem 2------------
balance = 42
balancex = balance
annualInterestRate = 0.2
# the able 2 fields are not for edx

monthlyInterestRate = annualInterestRate / 12

monthlyPayment = balance / 12
epsilon = 0.01
step = 0.01
while balancex != 0 and balancex <= balance:
    monthlyPayment += step
    x = 1
    while x <= 12 and balancex != 0 and balancex < balance:
        monthlyUnpaidBalance = balancex - monthlyPayment
        balancex = monthlyUnpaidBalance + (monthlyInterestRate * monthlyUnpaidBalance)
        x += 1
        print(balancex)
    if balancex == 0:
        print(monthlyPayment)
        break
    else:
        pass
